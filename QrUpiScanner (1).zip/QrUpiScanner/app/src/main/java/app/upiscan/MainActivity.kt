package app.upiscan

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.media.Image
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.TextureView
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.mlkit.vision.barcode.BarcodeScannerOptions
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage
import java.util.concurrent.atomic.AtomicBoolean

class MainActivity : AppCompatActivity(), CameraController.Listener {

    private lateinit var prefs: SharedPreferences
    private lateinit var tv: CoverTextureView
    private lateinit var cam: CameraController
    private lateinit var status: TextView
    private lateinit var errorView: TextView
    private lateinit var flashBtn: TextView
    private val lensBtns = LinkedHashMap<LensMode, TextView>()

    private var catalog: List<CamEntry> = emptyList()
    private var mode = LensMode.MAIN
    private var testing: CamEntry? = null
    private var current: CamEntry? = null
    private var torch = false
    private var locked = false
    private var lastRaw = ""
    private var lastRawAt = 0L
    private var lastAnalysis = 0L
    private val analyzing = AtomicBoolean(false)
    private val ui = Handler(Looper.getMainLooper())
    private var statusText = "Starting…"

    private val scanner by lazy {
        BarcodeScanning.getClient(BarcodeScannerOptions.Builder().setBarcodeFormats(Barcode.FORMAT_QR_CODE).build())
    }

    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) startSelected() else showError("Camera permission denied. Grant it in system settings to scan.")
    }

    private val pickImage = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) scanGallery(uri)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("upiscan", MODE_PRIVATE)
        mode = LensMode.values().firstOrNull { it.key == prefs.getString("mode", "main") } ?: LensMode.MAIN
        buildUi()
        cam = CameraController(this, tv, this)
    }

    private fun pill(color: Int = 0x99000000.toInt()) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(20).toFloat()
    }

    private fun buildUi() {
        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        tv = CoverTextureView(this)
        tv.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
            override fun onSurfaceTextureAvailable(s: SurfaceTexture, w: Int, h: Int) { cam.surfaceReady() }
            override fun onSurfaceTextureSizeChanged(s: SurfaceTexture, w: Int, h: Int) {}
            override fun onSurfaceTextureDestroyed(s: SurfaceTexture) = true
            override fun onSurfaceTextureUpdated(s: SurfaceTexture) {}
        }
        root.addView(tv, FrameLayout.LayoutParams(-1, -1, Gravity.CENTER))
        root.addView(ScanFrameView(this), FrameLayout.LayoutParams(-1, -1))

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(8))
        }
        status = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 13f; text = statusText
            background = pill(); setPadding(dp(14), dp(8), dp(14), dp(8))
        }
        top.addView(status, LinearLayout.LayoutParams(0, -2, 1f))
        flashBtn = iconBtn("🔦") { torch = !torch; cam.setTorch(torch); paintFlash() }
        top.addView(flashBtn); top.addView(iconBtn("🖼") { if (!locked) pickImage.launch("image/*") })
        top.addView(iconBtn("ⓘ") { showDiagnostics() })
        root.addView(top, FrameLayout.LayoutParams(-1, -2, Gravity.TOP))

        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(16), 0, dp(16), dp(28))
        }
        errorView = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 13f; visibility = View.GONE
            background = pill(0xCCB3261E.toInt()); setPadding(dp(14), dp(10), dp(14), dp(10))
        }
        bottom.addView(errorView, LinearLayout.LayoutParams(-2, -2).apply { bottomMargin = dp(14) })
        val seg = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (m in LensMode.values()) {
            val b = TextView(this).apply {
                text = m.label; textSize = 15f; gravity = Gravity.CENTER
                setPadding(dp(22), dp(10), dp(22), dp(10))
                setOnClickListener { selectMode(m) }
            }
            lensBtns[m] = b
            seg.addView(b, LinearLayout.LayoutParams(-2, -2).apply { marginStart = dp(4); marginEnd = dp(4) })
        }
        bottom.addView(seg)
        root.addView(bottom, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
        setContentView(root)
        paintLens(); paintFlash()
    }

    private fun iconBtn(t: String, click: () -> Unit) = TextView(this).apply {
        text = t; textSize = 18f; gravity = Gravity.CENTER; background = pill()
        layoutParams = LinearLayout.LayoutParams(dp(42), dp(42)).apply { marginStart = dp(8) }
        setOnClickListener { click() }
    }

    private fun paintLens() {
        for ((m, b) in lensBtns) {
            val sel = testing == null && m == mode
            b.background = pill(if (sel) Color.WHITE else 0x99000000.toInt())
            b.setTextColor(if (sel) Color.BLACK else Color.WHITE)
        }
    }

    private fun paintFlash() { flashBtn.background = pill(if (torch) 0xFFFFC107.toInt() else 0x99000000.toInt()) }

    private fun selectMode(m: LensMode) {
        mode = m; testing = null
        prefs.edit().putString("mode", m.key).apply()
        paintLens(); startSelected()
    }

    override fun onResume() {
        super.onResume()
        if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) startSelected()
        else permLauncher.launch(Manifest.permission.CAMERA)
    }

    override fun onPause() { cam.stop(); super.onPause() }

    private fun startSelected() {
        catalog = CameraCatalog.scan(this)
        val e = testing ?: CameraCatalog.resolve(catalog, mode, prefs)
        current = e
        if (e == null) {
            cam.closeCamera()
            tv.visibility = View.INVISIBLE
            showError("${mode.label} camera isn't available: the phone doesn't expose a matching lens to apps, " +
                "or it couldn't be identified. Tap ⓘ to inspect cameras and assign one manually.")
            return
        }
        hideError(); tv.visibility = View.VISIBLE
        setStatus("Opening ${label()}…")
        cam.show(e)
    }

    private fun label() = testing?.let { "test ${it.title}" } ?: "${mode.label} (${current?.title})"

    // ---- CameraController.Listener ----
    override fun onState(msg: String, error: Boolean) {
        if (error) { tv.visibility = View.INVISIBLE; showError(msg) }
        else { hideError(); tv.visibility = View.VISIBLE; setStatus("Scanning · ${label()}") }
    }

    override fun onFrame(img: Image, rotation: Int) {
        val now = SystemClock.elapsedRealtime()
        if (locked || now - lastAnalysis < 100 || !analyzing.compareAndSet(false, true)) { img.close(); return }
        lastAnalysis = now
        try {
            scanner.process(InputImage.fromMediaImage(img, rotation))
                .addOnSuccessListener { list -> for (b in list) { b.rawValue?.let { onQr(it, false) }; if (locked) break } }
                .addOnCompleteListener { img.close(); analyzing.set(false) }
        } catch (e: Exception) { img.close(); analyzing.set(false) }
    }

    // ---- QR handling ----
    private fun onQr(raw: String, force: Boolean) {
        if (locked) return
        val now = SystemClock.elapsedRealtime()
        if (!force && raw == lastRaw && now - lastRawAt < 2500) return   // duplicate suppression
        lastRaw = raw; lastRawAt = now
        when (val r = UpiParser.parse(raw)) {
            is ParseResult.Ok -> { locked = true; showPayment(r.req) }
            is ParseResult.Bad -> flash(r.reason)
        }
    }

    private fun scanGallery(uri: Uri) {
        try {
            scanner.process(InputImage.fromFilePath(this, uri))
                .addOnSuccessListener { l ->
                    val raw = l.firstOrNull { it.rawValue != null }?.rawValue
                    if (raw == null) flash("No QR code found in image") else onQr(raw, true)
                }
                .addOnFailureListener { flash("Could not read image") }
        } catch (e: Exception) { flash("Could not read image") }
    }

    private fun setStatus(t: String) { statusText = t; status.text = t }
    private fun flash(msg: String) {
        status.text = msg
        ui.removeCallbacksAndMessages(null)
        ui.postDelayed({ status.text = statusText }, 2000)
    }
    private fun showError(m: String) { errorView.text = m; errorView.visibility = View.VISIBLE; setStatus("Camera unavailable") }
    private fun hideError() { errorView.visibility = View.GONE }

    // ---- Payment sheet ----
    private fun upiApps(raw: String): List<ResolveInfo> {
        val i = Intent(Intent.ACTION_VIEW, Uri.parse(raw))
        val pm = packageManager
        return pm.queryIntentActivities(i, PackageManager.MATCH_DEFAULT_ONLY)
            .filter { it.activityInfo.packageName != packageName }
            .sortedWith(compareBy({ !it.loadLabel(pm).toString().contains("fam", true) }, { it.loadLabel(pm).toString().lowercase() }))
    }

    private fun showPayment(req: UpiRequest) {
        val d = BottomSheetDialog(this)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(24), dp(20), dp(24), dp(28)) }
        fun field(k: String, v: String, big: Boolean = false) {
            col.addView(TextView(this).apply { text = k; textSize = 12f; alpha = 0.6f })
            col.addView(TextView(this).apply { text = v; textSize = if (big) 22f else 16f; setPadding(0, 0, 0, dp(12)) })
        }
        col.addView(TextView(this).apply { text = "Verify before paying"; textSize = 13f; alpha = 0.6f; setPadding(0, 0, 0, dp(12)) })
        field("Recipient", req.pn ?: "(name not provided)", true)
        field("UPI ID", req.pa)
        field("Amount", req.am?.let { "₹ $it" } ?: "Not set — you'll enter it in the payment app", req.am != null)
        req.tn?.let { field("Note", it) }
        col.addView(TextView(this).apply { text = "Pay with"; textSize = 12f; alpha = 0.6f; setPadding(0, dp(8), 0, dp(6)) })

        val apps = upiApps(req.raw)
        val pm = packageManager
        for (ri in apps) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(8), 0, dp(8))
                setOnClickListener {
                    d.dismiss()
                    try {
                        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(req.raw))
                            .setClassName(ri.activityInfo.packageName, ri.activityInfo.name))
                    } catch (e: Exception) { Toast.makeText(this@MainActivity, "Couldn't open that app", Toast.LENGTH_SHORT).show() }
                }
            }
            row.addView(ImageView(this).apply { setImageDrawable(ri.loadIcon(pm)) }, LinearLayout.LayoutParams(dp(40), dp(40)))
            row.addView(TextView(this).apply { text = ri.loadLabel(pm); textSize = 16f; setPadding(dp(14), 0, 0, 0) })
            col.addView(row)
        }
        if (apps.isEmpty()) col.addView(TextView(this).apply { text = "No installed app registers for UPI payment links." })
        else col.addView(TextView(this).apply {
            text = "Other…"; textSize = 15f; setPadding(0, dp(10), 0, dp(4)); alpha = 0.8f
            setOnClickListener {
                d.dismiss()
                startActivity(Intent.createChooser(Intent(Intent.ACTION_VIEW, Uri.parse(req.raw)), "Pay with"))
            }
        })
        col.addView(TextView(this).apply {
            text = "Nothing is paid until you confirm inside the payment app. This scanner never sees your UPI PIN or payment result."
            textSize = 11f; alpha = 0.5f; setPadding(0, dp(16), 0, 0)
        })
        d.setContentView(col)
        d.setOnDismissListener { locked = false; lastRawAt = SystemClock.elapsedRealtime() }
        d.show()
    }

    // ---- Diagnostics ----
    private fun showDiagnostics() {
        catalog = CameraCatalog.scan(this)
        val reportText = CameraCatalog.report(this, catalog, prefs)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(8), dp(16), dp(8)) }
        col.addView(TextView(this).apply { text = reportText; typeface = Typeface.MONOSPACE; textSize = 11f; setTextIsSelectable(true) })
        for (e in catalog.filter { it.usable }) {
            col.addView(TextView(this).apply { text = e.title; textSize = 13f; setPadding(0, dp(12), 0, 0) })
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            fun btn(t: String, a: () -> Unit) = Button(this).apply {
                text = t; textSize = 11f; isAllCaps = false; setOnClickListener { a() }
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
            }
            row.addView(btn("Test") { testing = e; paintLens(); startSelected() })
            for (m in LensMode.values()) row.addView(btn("→ ${m.label}") {
                prefs.edit().putString("map_${m.key}", e.key).apply()
                Toast.makeText(this, "${m.label} = ${e.title}", Toast.LENGTH_SHORT).show()
                if (testing == null && mode == m) startSelected()
            })
            col.addView(row)
        }
        AlertDialog.Builder(this).setTitle("Camera diagnostics")
            .setView(ScrollView(this).apply { addView(col) })
            .setPositiveButton("Close", null)
            .setNeutralButton("Copy report") { _, _ ->
                (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
                    .setPrimaryClip(ClipData.newPlainText("camera report", reportText))
            }
            .setNegativeButton("Reset mapping") { _, _ ->
                prefs.edit().apply { LensMode.values().forEach { remove("map_${it.key}") } }.apply()
                testing = null; paintLens(); startSelected()
            }.show()
    }
}

/** Fills the parent (centre-crop) while keeping the camera aspect ratio. */
class CoverTextureView(ctx: Context) : TextureView(ctx) {
    private var ratio = 0f
    fun setImageRatio(r: Float) { if (r != ratio) { ratio = r; requestLayout() } }
    override fun onMeasure(wSpec: Int, hSpec: Int) {
        val pw = MeasureSpec.getSize(wSpec); val ph = MeasureSpec.getSize(hSpec)
        if (ratio <= 0f || pw == 0 || ph == 0) { setMeasuredDimension(pw, ph); return }
        if (pw.toFloat() / ph > ratio) setMeasuredDimension(pw, (pw / ratio).toInt())
        else setMeasuredDimension((ph * ratio).toInt(), ph)
    }
}

/** Visual guide only: the whole frame is analysed, so off-centre / small QR codes still work. */
class ScanFrameView(ctx: Context) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; style = Paint.Style.STROKE; strokeWidth = 4f * resources.displayMetrics.density
        strokeCap = Paint.Cap.ROUND
    }
    override fun onDraw(c: Canvas) {
        val s = minOf(width, height) * 0.62f
        val l = (width - s) / 2; val t = (height - s) / 2 - height * 0.04f
        val r = l + s; val b = t + s; val k = s * 0.14f
        c.drawLines(floatArrayOf(
            l, t, l + k, t, l, t, l, t + k, r, t, r - k, t, r, t, r, t + k,
            l, b, l + k, b, l, b, l, b - k, r, b, r - k, b, r, b, r, b - k), p)
    }
}
